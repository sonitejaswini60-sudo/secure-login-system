# Secure Login System

Task 4: Secure Login System built with Python Flask and SQLite.

## Features

- User registration
- Secure password hashing with bcrypt
- Login authentication
- Input validation
- Parameterized SQL queries to reduce SQL injection risk
- Session management
- Logout
- Protected dashboard

## Project Structure

```text
Task_4_Secure_Login_System/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   ├── login.html
│   ├── register.html
│   └── dashboard.html
└── static/
    └── style.css
```

## Installation

```bash
pip install -r requirements.txt
```

## Run

```bash
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

Register an account, log in, and test the logout feature.

## Security Notes

Passwords are never stored as plain text. They are hashed using bcrypt.

Database operations use parameterized queries instead of directly inserting user input into SQL statements.

The application uses Flask sessions to keep track of authenticated users.

For production deployment, set a strong random `SECRET_KEY`, disable debug mode, use HTTPS, and consider adding CSRF protection, rate limiting, secure cookie settings, and optional 2FA.
